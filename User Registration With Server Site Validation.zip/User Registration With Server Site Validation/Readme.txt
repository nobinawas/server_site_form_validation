How to run the Script

1. Download the zip file

2. Extract the file and copy practice folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name practice

6. Import tblregistration.sql file (given inside the zip package in SQL file folder)

7.Run the script http://localhost/practice 
